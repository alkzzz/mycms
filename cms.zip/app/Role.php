<?php

namespace cms;

use Zizaco\Entrust\EntrustRole;

class Role extends EntrustRole
{
	
}