<?php

namespace cms;

use Zizaco\Entrust\EntrustPermission;

class Permission extends EntrustPermission
{
	
}