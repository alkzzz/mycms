<?php

namespace cms;

use Illuminate\Database\Eloquent\Model;

class SubMenu extends Model
{
    protected $table = 'sub_menu';

    protected $fillable = ['urutan','title_id', 'slug_id', 'content_id', 
    						'title_en', 'slug_en', 'content_en' ];

    public function menu()
    {
    	return $this->belongsTo('cms\Menu', 'id_menu');
    }
}
