<?php
#BackEnd
Route::group(['as' => 'dashboard::'], function () {
		Route::get('dashboard', ['as'=>'home', 'uses'=>'DashboardController@index']);
		Route::get('dashboard/menu',['as'=>'menu', 'uses'=>'MenuController@index']);
});

Route::get('dosen', 'DosenController@index');

Route::get('menu', 'MenuController@cekUrutan');
Route::post('menu', 'MenuController@postUrutan');

Route::get('testing', function(){
	return view('dashboard.menu_list');
});

//Entrust::routeNeedsRole('dashboard', 'admin');
Entrust::routeNeedsRole('dosen', 'dosen');

#Auth
Route::get('login', 'Auth\AuthController@getLogin');
Route::post('login', ['as'=>'login','uses'=>'Auth\AuthController@postLogin']);
Route::get('logout', 'Auth\AuthController@getLogout');


Route::get('data.user', ['as'=>'all_data_user', 'uses'=>'DashboardController@all_data_user']);
Route::get('user', ['as'=>'all_user' ,'uses'=>'DashboardController@index']);

#FrontEnd
Route::group(['prefix' => Localization::setLocale(), 'middleware' => ['localize'] ], function()
{
    Route::get('/', ['as'=>'homepage', 'uses'=>'HomeController@index']);

    Route::get('{menu}', 'MenuController@show');

    Route::get('{menu}/{submenu}', 'SubmenuController@show');
    
});
