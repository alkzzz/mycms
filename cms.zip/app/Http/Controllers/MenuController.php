<?php

namespace cms\Http\Controllers;

use Illuminate\Http\Request;
use cms\Http\Requests;
use cms\Http\Controllers\Controller;
use Localization;
use cms\Menu;
use cms\SubMenu;

class MenuController extends Controller
{

    public function __construct()
    {
        $this->middleware('menu');
    }

	public function cekUrutan(Request $request)
	{
		$data = session('data');
		parse_str($data['urutan'], $urutan);
        dd($urutan);
		return view('dashboard.daftarmenu1')->with('urutan', $urutan);

	}

    public function postUrutan(Request $request)
    {
    	$data = $request->all();
        parse_str($data['urutan'], $urutan);
        $count = count($urutan['menu']);  
        $daftarmenu = Menu::all();
        $daftarsubmenu = Submenu::all();

        foreach ($urutan['menu'] as $slug => $value) {
            foreach ($daftarmenu as $menu) { 
                $i = array_search($menu->slug_id, array_keys($urutan['menu']));
                $menu->urutan = $i;
                $menu->save();
            }
        }
        foreach ($urutan['submenu'] as $sub => $menu) {
            foreach ($daftarsubmenu as $submenu) {
                $i = array_search($submenu->slug_id, array_keys($urutan['submenu']));
                $submenu->urutan = $i;
                $submenu->save();
            }
        }

        return redirect('/menu')->with('data', $data);
    }

    public function ubahUrutanMenu(Request $request)
    {

    }

    public function index()
    {
        $title = 'Menu';
    	$daftarmenu = Menu::with(['submenu' => function ($query) {
                    $query->orderBy('urutan', 'asc');
                    }])->get()->sortBy('urutan');
    	return view('menu.list', compact('title','daftarmenu'));
    }



    public function show($menu)
    {
        $locale = Localization::getCurrentLocale();
        $page = Menu::where('slug_'.$locale, '=', $menu)->firstOrFail();
        return view('menu.show', compact('page'));
    }

}
