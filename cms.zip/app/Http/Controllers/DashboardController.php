<?php

namespace cms\Http\Controllers;

use Illuminate\Http\Request;

use cms\Http\Requests;
use cms\Http\Controllers\Controller;
use cms\User;
use Datatables;

class DashboardController extends Controller
{

    public function __construct()
    {
        $this->middleware('role:admin');
    }

  	public function index()
  	{
      $title = 'Home';
  		return view('dashboard.index', compact('title'));
  	}

  	public function all_data_user()
  	{
  		return Datatables::of(User::select('*'))->make(true);
  	}

  	public function berita()
  	{
  		return trans('menu.news');
  	}
}
