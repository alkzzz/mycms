<?php

namespace cms\Http\Middleware;

use Closure;
use Localization;
use MainMenu;
use cms\Menu;
use cms\Submenu;

class GenerateMenu
{
    /**
     * Run the request filter.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure                  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
    

    MainMenu::make('mainmenu', function($mainmenu) {
        $locale = Localization::getCurrentLocale();
        $daftar_menu = Menu::with(['submenu' => function ($query) {
                            $query->orderBy('urutan', 'asc');
                            }])->get()->sortBy('urutan');
        $mainmenu->add('Home', url('/'));
        foreach ($daftar_menu as $menu) {
            if ($locale == 'id') {
                $submenu = $mainmenu->add($menu->title_id, 'id'.'/'.$menu->slug_id);
                if (count($menu->submenu)) {
                    foreach ($menu->submenu as $sub) {
                        $submenu->add($sub->title_id, 'id'.'/'.$menu->slug_id.'/'.$sub->slug_id);
                    }
                }
            }
            else
            {
               $submenu = $mainmenu->add($menu->title_en, 'en'.'/'.$menu->slug_en);
                if (count($menu->submenu)) {
                    foreach ($menu->submenu as $sub) {
                        $submenu->add($sub->title_en, 'en'.'/'.$menu->slug_en.'/'.$sub->slug_en);
                    }
                }
            }
        }
        
    });

        return $next($request);
    }
}
