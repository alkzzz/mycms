<?php

namespace cms\Events;

abstract class Event
{
    //
}
