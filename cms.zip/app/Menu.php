<?php

namespace cms;

use Illuminate\Database\Eloquent\Model;

class Menu extends Model
{
   	protected $table = 'menu';

    protected $fillable = ['urutan','has_submenu','title_id', 'slug_id', 'content_id', 
    						'title_en', 'slug_en', 'content_en' ];

    public function submenu()
    {
    	return $this->hasMany('cms\Submenu', 'id_menu');
    }

}
