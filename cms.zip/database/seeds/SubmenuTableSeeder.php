<?php

use Illuminate\Database\Seeder;

class SubmenuTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	factory('cms\Submenu', 10)->create();
    }
}
