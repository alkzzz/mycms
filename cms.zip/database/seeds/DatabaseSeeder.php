<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        DB::statement("SET foreign_key_checks = 0");

        DB::table('users')->truncate();
        DB::table('sub_menu')->truncate();
        DB::table('menu')->truncate();

        $this->call(UserTableSeeder::class);
        $this->call(MenuTableSeeder::class);
        $this->call(SubmenuTableSeeder::class);

        Model::reguard();
    }
}
