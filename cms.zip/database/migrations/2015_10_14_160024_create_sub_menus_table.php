<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSubMenusTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sub_menu', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('id_menu')->unsigned();
            $table->integer('urutan')->unsigned();
            $table->string('title_id');
            $table->string('slug_id');
            $table->text('content_id');
            $table->string('title_en');
            $table->string('slug_en');
            $table->text('content_en');
            $table->timestamps();

            $table->foreign('id_menu')
                    ->references('id')->on('menu')
                    ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('sub_menu');
    }
}
